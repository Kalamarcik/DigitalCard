package com.example.digitalcard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalCardApplicationTests {

    @Test
    void contextLoads() {
    }

}
